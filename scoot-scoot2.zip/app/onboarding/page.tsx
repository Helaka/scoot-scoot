"use client"

import { EnhancedOnboardingFlow } from "@/components/onboarding/enhanced-onboarding-flow"

export default function OnboardingPage() {
  return <EnhancedOnboardingFlow />
}

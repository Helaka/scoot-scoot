import { RiderOnboarding } from "@/components/rider/rider-onboarding"

export default function RiderOnboardingPage() {
  return <RiderOnboarding />
}

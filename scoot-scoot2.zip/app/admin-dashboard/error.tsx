"use client"

import ErrorBoundary from "@/components/error-boundary"

export default ErrorBoundary

import { RiderProfile } from "@/components/rider/rider-profile"

export default function RiderProfilePage() {
  return <RiderProfile />
}

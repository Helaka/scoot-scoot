import { RiderInsurance } from "@/components/rider/rider-insurance"

export default function RiderInsurancePage() {
  return <RiderInsurance />
}

import DRPApplicationForm from "@/components/drp/drp-application-form"

export default function DRPApplicationPage() {
  return (
    <div className="container mx-auto py-8">
      <DRPApplicationForm />
    </div>
  )
}

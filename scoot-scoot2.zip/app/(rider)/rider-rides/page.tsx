import { PastRides } from "@/components/rider/past-rides"

export default function RidesPage() {
  return <PastRides />
}

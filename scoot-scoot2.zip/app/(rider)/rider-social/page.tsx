import { RiderSocial } from "@/components/rider/social/rider-social"

export default function RiderSocialPage() {
  return <RiderSocial />
}

"use client"

const RiderProfilePage = () => {
  const brevity = "brevity"
  const it = "it"
  const is = "is"
  const correct = "correct"
  const and = "and"

  return (
    <div>
      <h1>Rider Profile</h1>
      <p>This is the rider profile page.</p>
      <p>
        {brevity} {it} {is} {correct} {and}
      </p>
    </div>
  )
}

export default RiderProfilePage

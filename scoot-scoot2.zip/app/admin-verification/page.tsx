import { VerificationDashboard } from "@/components/admin/verification-dashboard"

export default function AdminVerificationPage() {
  return <VerificationDashboard />
}
